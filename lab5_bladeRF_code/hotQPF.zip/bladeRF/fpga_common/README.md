This directory contains files shared between the FPGA NIOS II processor
and host code.
